# Expense Tracker (Flutter + Dart)

A beginner-friendly expense tracker app with local storage.

## Features
- Add an expense title, amount, category, date, and optional note
- View total spending for this month, this week, or all time
- View recent expenses
- Delete an expense and undo the deletion
- Saves expenses on the device using `shared_preferences`
- Currency display uses Indian rupees (₹)

## Requirements
- Flutter SDK installed
- Android Studio or VS Code with Flutter and Dart extensions

## Run the project
1. Extract `expense_tracker_dart.zip`.
2. Open the extracted `expense_tracker` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

   ```bash
   flutter doctor
   flutter pub get
   flutter run
   ```

5. Choose a connected Android phone or an emulator when prompted.

## Notes
- Data is stored locally on the device; it is not synced to a cloud account.
- The app uses `shared_preferences` for simple local persistence.
- This ZIP contains the app source and configuration, not the Flutter SDK or Android SDK.
